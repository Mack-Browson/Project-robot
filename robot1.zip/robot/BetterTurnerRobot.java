import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BetterTurnerRobot here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BetterTurnerRobot extends UrRobot 
{
    
    public BetterTurnerRobot(int street, int avenue, KarelWorld.Direction direction, int beepers){
        super( street, avenue, direction, beepers);
    }
    /**
     * Populats the world
     * @param  myWorld  String with the name of the world
     */
    public static void populate(String myWorld)
    {
        KarelWorld world = KarelWorld.itself();
        world.readWorld("worlds", myWorld);
    }
    
    /**
     * Act - do whatever the BetterTurnerRobot wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
      
    public void act() 
    {
        // Add your action code here.
    }
    
    /**
     * Turn the robot to the right (pointing to the WEST)
     */

    public void turnRight()
    {
        turnAround();
        turnLeft();
    }

    /**
     * Turns the robot around
     */
    public void turnAround()
    {
        turnLeft();
        turnLeft();
    }
    
    
    /**
     * Places a beeper in the current position where the robot is and moves one position
     */
    public void placeBeeper()
    {
        putBeeper();
        move();
    }
    
    /**
     * Places an amount of beeper in the current position where the robot is 
     * @param  num the location of beepers to place in current robot position
     */
    public void placeBeepers(int num)
    {
        for(int i=0; i < num; i++)
            placeBeeper();  
    }

    /**
     * Moves the robot a given amount of steps in the pointing direction
     * @param  num The amount of steps the robot has to move in the pointing direction
     */   
    public void move(int num)
    {
        for(int i=0; i < num; i++)
            move();
    }
    
    /**
     * Moves the robot six step in the pointing direction
     */   
    public void mile()
    {
        move(6);
    }

    /**
     * Moves the robot upwards the mount of times specified (asuming it points to the EAST) and ends pointing the same direction
     * @param  num the location of beepers to place in current robot position
     */   
    public void up(int num)
    {
        turnLeft();
        move(num);
        turnRight();
    }
    
    /**
     * Moves the robot downwards the mount of times specified (asuming it points to the EAST) and ends pointing the same direction
     * @param  num the location of beepers to place in current robot position
     */   
    public void down(int num)
    {
        turnRight();
        move(num);
        turnLeft();
    }
    
    /**
     * Moves the robot to the upper left corner, assuming a width of 4 and a height of 5 from current position
     */   
    public void up5LeftCorner()
    {
        setLocation(getX()-4, getY()-5); //4 es la anchura, y 5 la altura
/*      turnLeft();
        move(4);
        move();
        turnLeft();
        move(4);
        turnAround();
*/
    }
    
    /**
     * Places 5 beepers upwards, asuming it points to the EAST, and ends pointing the same direction
     */   
    public void up5Beepers()
    {
        turnLeft();
        placeBeepers(4);
        turnRight();
        placeBeeper();
    }
    
    /**
     * Place several beepers in a row
     * @param  num the amount of: positions the robot has to move and beepers it has to place 
     */       
    public void pickRow(int num)
    {
       for(int i=0; i < num; i++){
            move();
            pickBeeper();
        }
    }
    
    /**
     * Move the robot to the position on its WEST
     */       
    public void nextRowWest()
    {
        turnLeft();
        move();
        turnLeft();
    }
    
    /**
     * Move the robot to the position on its EAST
     */       
    public void nextRowEast()
    {
        turnLeft();
        move();
        turnRight();
    }
    
    /**
     * Move the robot to the home position
     */   
    public void goHome()
    {

    }
    
    /**
     * Move the robot one position on the opposite direction to the one it is pointing
     */       
    public void moveBackward()
    {
        turnAround();
        move();
        turnAround();
    }
    
    /**
     * Establish the position of the robot in the world
     * @param  street Street in which to place the robot
     * @param  avenue Avenue in which to place the robot
     */   
    public void setPosition(int street, int avenue){
        KarelWorld world = KarelWorld.itself();
        setLocation(avenue-1, world.getHeight()-street);
    }
    
    /**
     * Gather current robot street
     * @return  Street in which the robot is located
     */   
    public int getStreet(){
        KarelWorld world = KarelWorld.itself();
        return world.getHeight()-getY();
    }
    
    /**
     * Gather current robot avenue
     * @return  Avenue in which the robot is located
     */   
    public int getAvenue(){
        return getX()+1;
    }
}


