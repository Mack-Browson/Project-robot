/**
 * Write a description of class HolaRobotTask here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HolaRobotTask  
{
    // instance variables - replace the example below with your own
     

    /**
     * Constructor for objects of class HolaRobotTask
     */
    
    
    public static void escribeHolaHorizontal(HolaRobot holarobot){
          
          holarobot.drawH();
          holarobot.draw0();
          holarobot.drawL();
          holarobot.drawA();
     
    }
    
    public static void escribeHolaDiagonal(HolaRobot holarobot){
          holarobot.drawH();
          holarobot.move();
          holarobot.setPosition(6,6);
          holarobot.draw0();
          holarobot.move();
          holarobot.setPosition(11,10);
          holarobot.drawL();
         holarobot.move();
         holarobot.setPosition(16,14);
          holarobot.drawA();
    
    }
    
    public static void escribirHolaVertical(HolaRobot holarobot){
          
          holarobot.drawH();
          holarobot.move();
          holarobot.setPosition(6,2);
          holarobot.draw0();
          holarobot.move();
          holarobot.setPosition(11,2);
          holarobot.drawL();
         holarobot.move();
         holarobot.setPosition(16,2);
          holarobot.drawA();
           
    }
    
}
