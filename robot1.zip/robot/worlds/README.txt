These are all of the world files for the book. The files are text files but have unix endlines. You may need to translate the endlines to edit them unless you use an editor that can read them.

