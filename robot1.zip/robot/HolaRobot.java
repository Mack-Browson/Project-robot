/**
 * Write a description of class HolaRobot here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HolaRobot  extends BetterTurnerRobot
{
    // instance variables - replace the example below with your own
    public HolaRobot(){
       super( 1, 2,KarelWorld.EAST , 500);
    }
    
     public HolaRobot(int street, int avenue, KarelWorld.Direction direction, int beepers){
       super( street, avenue,KarelWorld.EAST , beepers);
    }
    
    public void drawH(){
        turnLeft();
        placeBeepers(5);
        turnAround();
        move(3);
        turnLeft();
        placeBeepers(4);
        turnAround();
        move(1);
        turnLeft();
        move(2);
        turnAround();
        placeBeepers(5);
        turnAround();
        move(5);
        turnLeft();
        move(1);
        
        
        
    
    }
    
    public void draw0(){
        placeBeepers(3);
        turnLeft();
        placeBeepers(4);
        turnLeft();
        placeBeepers(3);
        turnLeft();
        placeBeepers(4);
        turnLeft();
        move(4);
    
    }
    
    public void drawL(){
        turnLeft();
        placeBeepers(5);
        turnAround();
        move(5);
        turnLeft();
        placeBeepers(4);
        
   
    
    }
    
    public void drawA(){
          turnLeft();
          placeBeepers(4);
          turnRight();
          placeBeepers(3);
          turnRight();
          placeBeepers(2);
          turnRight();
          placeBeepers(3);
          turnAround();
          move(3);
          turnRight();
          placeBeepers(3);
          turnRight();
          move(2);
          
          
          
          
          
          
          
          
          
          
       
          
         
          
          
    
    }
}
